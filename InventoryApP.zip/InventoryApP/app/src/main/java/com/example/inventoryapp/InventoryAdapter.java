package com.example.inventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private InventoryItem[] inventoryItems;
    private OnItemClickListener mListener;

    // Constructor to initialize with an array of inventory items and click listener
    public InventoryAdapter(InventoryItem[] inventoryItems, OnItemClickListener listener) {
        this.inventoryItems = inventoryItems;
        this.mListener = listener;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new InventoryViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem currentItem = inventoryItems[position];
        holder.itemNameTextView.setText(currentItem.getItemName());
        holder.quantityTextView.setText(String.valueOf(currentItem.getQuantity()));
    }

    @Override
    public int getItemCount() {
        return inventoryItems.length;
    }

    public void updateData(InventoryItem[] inventoryItems) {
        this.inventoryItems = inventoryItems;
        notifyDataSetChanged();
    }

    public class InventoryViewHolder extends RecyclerView.ViewHolder {
        public TextView itemNameTextView;
        public TextView quantityTextView;
        public Button removeButton;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            quantityTextView = itemView.findViewById(R.id.quantityTextView);
            removeButton = itemView.findViewById(R.id.removeButton);

            removeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mListener != null) {
                        mListener.onRemoveItemClick(getAdapterPosition());
                    }
                }
            });
        }
    }

    // Interface for handling item click events
    public interface OnItemClickListener {
        void onRemoveItemClick(int position);
    }
}
