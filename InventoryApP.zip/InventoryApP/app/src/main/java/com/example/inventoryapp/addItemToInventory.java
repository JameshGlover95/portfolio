package com.example.inventoryapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class addItemToInventory extends AppCompatActivity {

    private EditText itemNameEditText;
    private EditText quantityEditText;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item_to_inventory);

        // Initialize UI elements
        itemNameEditText = findViewById(R.id.editTextItemName);
        quantityEditText = findViewById(R.id.editTextQuantity);
        Button addButton = findViewById(R.id.buttonAddItem);

        // Set OnClickListener for the Add button
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItemToInventory();
            }
        });
    }

    private void addItemToInventory() {
        String itemName = itemNameEditText.getText().toString().trim();
        int quantity = Integer.parseInt(quantityEditText.getText().toString().trim());

        // Set the result to be sent back to the Inventory activity
        Intent resultIntent = new Intent();
        resultIntent.putExtra("itemName", itemName);
        resultIntent.putExtra("quantity", quantity);
        setResult(RESULT_OK, resultIntent);

        // Finish the activity
        finish();
    }
}
