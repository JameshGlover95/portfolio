package com.example.inventoryapp;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegistrationActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        dbHelper = new DatabaseHelper(this);

        findViewById(R.id.buttonRegister).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = ((EditText) findViewById(R.id.editTextUsername)).getText().toString();
                String password = ((EditText) findViewById(R.id.editTextPassword)).getText().toString();
                String phoneNumber = ((EditText) findViewById(R.id.editTextPhoneNumber)).getText().toString();

                if (!username.isEmpty() && !password.isEmpty() && !phoneNumber.isEmpty()) {
                    long id = dbHelper.addUser(username, password, phoneNumber);
                    if (id != -1) {
                        Toast.makeText(RegistrationActivity.this, "Registration Successful", Toast.LENGTH_SHORT).show();

                        // Pass phone number to Permissions class
                        Permissions permissions = new Permissions(RegistrationActivity.this, phoneNumber);
                        permissions.sendSmsIfInventoryLow();

                        finish(); // Finish the activity after successful registration
                    } else {
                        Toast.makeText(RegistrationActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(RegistrationActivity.this, "Please enter username, password, and phone number", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
