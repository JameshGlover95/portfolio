package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private boolean isAuthenticated = false;
    private int userId = -1; // Default value indicating no user logged in

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        // Check if the user is already authenticated
        isAuthenticated = checkAuthentication();

        if (isAuthenticated) {
            // If the user is already authenticated, navigate to the main menu
            navigateToMainMenu();
        } else {
            // If not authenticated, set up login and registration buttons
            setUpLoginButton();
            setUpRegistrationButton();
        }
    }

    // Method to check if the user is already authenticated
    private boolean checkAuthentication() {
        // Implement your authentication logic here, such as checking if the user has an active session or token
        // For demonstration purposes, let's assume the user is authenticated if they have logged in before
        userId = dbHelper.getLoggedInUserId(); // Retrieve the user ID of the logged-in user
        return userId != -1; // If user ID is not -1, user is authenticated
    }

    // Method to set up the login button click listener
    private void setUpLoginButton() {
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = ((EditText) findViewById(R.id.editTextTextPassword2)).getText().toString();
                String password = ((EditText) findViewById(R.id.editTextTextPassword)).getText().toString();

                userId = dbHelper.checkUserAndGetId(username, password); // Check user and get user ID

                if (userId != -1) {
                    // Authentication successful, navigate to the main menu
                    isAuthenticated = true;
                    dbHelper.setLoggedInUserId(userId); // Store the logged-in user ID
                    navigateToMainMenu();
                } else {
                    // Authentication failed, display error message
                    Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to set up the registration button click listener
    private void setUpRegistrationButton() {
        findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the registration activity
                startActivity(new Intent(MainActivity.this, RegistrationActivity.class));
            }
        });
    }

    // Method to navigate to the main menu activity
    private void navigateToMainMenu() {
        Intent intent = new Intent(MainActivity.this, main_menu.class);
        startActivity(intent);
        finish(); // Finish the current activity to prevent the user from coming back with the back button
    }
}
