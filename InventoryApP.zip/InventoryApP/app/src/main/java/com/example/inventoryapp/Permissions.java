package com.example.inventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;
import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class Permissions extends AppCompatActivity {

    private String userPhoneNumber; // Variable to hold user phone number

    private Context context; // Context variable
    private static final int PERMISSION_REQUEST_SEND_SMS = 1;

    // Constructor with parameters
    public Permissions(Context context, String phoneNumber) {
        this.context = context;
        this.userPhoneNumber = phoneNumber;
    }

    // Method to set user phone number
    public void setUserPhoneNumber(String phoneNumber) {
        this.userPhoneNumber = phoneNumber;
    }

    // Method to send SMS if inventory is low
    public void sendSmsIfInventoryLow() {
        // Check if SMS permission is granted
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            if (userPhoneNumber != null && !userPhoneNumber.isEmpty()) {
                // Continue with SMS sending logic
                String message = "Inventory is low. Please restock!";
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(userPhoneNumber, null, message, null, null);
                Toast.makeText(context, "SMS sent: " + message, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Phone number not available.", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Permission is not granted, request it
            ActivityCompat.requestPermissions((AppCompatActivity) context, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SEND_SMS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults); // Call super method
        if (requestCode == PERMISSION_REQUEST_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, send SMS if inventory is low
                sendSmsIfInventoryLow();
            } else {
                // Permission denied, show a message or disable SMS functionality
                Toast.makeText(context, "SMS permission denied. Cannot send SMS.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
