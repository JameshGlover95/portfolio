package com.example.inventoryapp;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class InventoryViewModel extends ViewModel {
    private MutableLiveData<InventoryItem[]> inventoryLiveData = new MutableLiveData<>();

    public LiveData<InventoryItem[]> getInventoryLiveData() {
        return inventoryLiveData;
    }

    public void setInventory(InventoryItem[] inventory) {
        inventoryLiveData.setValue(inventory);
    }
}
