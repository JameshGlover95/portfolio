package com.example.inventoryapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Inventory extends AppCompatActivity implements InventoryAdapter.OnItemClickListener {

    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private View emptyView;
    private InventoryViewModel inventoryViewModel;
    private static final int ADD_ITEM_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize empty view
        LayoutInflater inflater = LayoutInflater.from(this);
        emptyView = inflater.inflate(R.layout.item_empty_inventory, recyclerView, false);

        // Initialize ViewModel
        inventoryViewModel = new ViewModelProvider(this).get(InventoryViewModel.class);

        // Observe changes in the inventory data
        inventoryViewModel.getInventoryLiveData().observe(this, new Observer<InventoryItem[]>() {
            @Override
            public void onChanged(InventoryItem[] inventoryItems) {
                updateView(inventoryItems);
            }
        });

        // Load inventory from storage
        loadInventoryFromStorage();

        // Find the "Add Item" button by ID
        Button addItemButton = findViewById(R.id.addDataButton);
        // Set OnClickListener to navigate to the addItemToInventory activity
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Inventory.this, addItemToInventory.class);
                startActivityForResult(intent, ADD_ITEM_REQUEST_CODE);
            }
        });

        // Find the main menu button by ID
        Button mainMenuButton = findViewById(R.id.mainMenuButton);
        // Set OnClickListener to save changes and go back to the main menu
        mainMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveChanges();
                // Navigate back to the main menu
                startActivity(new Intent(Inventory.this, main_menu.class));
                finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_ITEM_REQUEST_CODE && resultCode == RESULT_OK) {
            // Get the added item's details from the Intent
            String itemName = data.getStringExtra("itemName");
            int quantity = data.getIntExtra("quantity", 0);
            // Add the new item to the inventory
            addItemToInventory(itemName, quantity);
        }
    }

    private void loadInventoryFromStorage() {
        // Load inventory from storage
        SharedPreferences sharedPreferences = getSharedPreferences("inventory_prefs", MODE_PRIVATE);
        String inventoryData = sharedPreferences.getString("inventory_data", "");

        InventoryItem[] inventoryItems;
        if (!inventoryData.isEmpty()) {
            String[] items = inventoryData.split("\\|");
            inventoryItems = new InventoryItem[items.length];
            for (int i = 0; i < items.length; i++) {
                String[] itemData = items[i].split(":");
                String itemName = itemData[0];
                int quantity = Integer.parseInt(itemData[1]);
                inventoryItems[i] = new InventoryItem(itemName, quantity);
            }
        } else {
            inventoryItems = new InventoryItem[0];
        }

        // Update ViewModel with loaded inventory
        inventoryViewModel.setInventory(inventoryItems);

        // Update the view
        updateView(inventoryItems);
    }

    private void updateView(InventoryItem[] inventoryItems) {
        // Update view based on inventory state
        if (inventoryItems.length > 0) {
            recyclerView.setVisibility(View.VISIBLE);
            emptyView.setVisibility(View.GONE);
            if (adapter == null) {
                adapter = new InventoryAdapter(inventoryItems, this);
                recyclerView.setAdapter(adapter);
            } else {
                adapter.updateData(inventoryItems);
                adapter.notifyDataSetChanged();
            }
        } else {
            recyclerView.setVisibility(View.GONE);
            emptyView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onRemoveItemClick(int position) {
        InventoryItem[] currentItems = inventoryViewModel.getInventoryLiveData().getValue();
        if (currentItems != null && currentItems.length > position) {
            currentItems[position].decrementQuantity(); // Assuming decrementQuantity() reduces the item quantity by one
            if (currentItems[position].isOutOfStock()) {
                removeItemFromInventory(position);
            } else {
                inventoryViewModel.setInventory(currentItems);
            }
        }
    }

    private void removeItemFromInventory(int position) {
        InventoryItem[] currentItems = inventoryViewModel.getInventoryLiveData().getValue();
        if (currentItems != null && currentItems.length > position) {
            List<InventoryItem> itemList = new ArrayList<>(Arrays.asList(currentItems));
            itemList.remove(position);
            InventoryItem[] updatedItems = itemList.toArray(new InventoryItem[0]);
            inventoryViewModel.setInventory(updatedItems);
        }
    }

    private void saveChanges() {
        // Get the current inventory from the ViewModel
        InventoryItem[] currentItems = inventoryViewModel.getInventoryLiveData().getValue();
        if (currentItems != null) {
            // Convert the inventory to a string format (itemName:quantity|itemName:quantity|...)
            StringBuilder inventoryData = new StringBuilder();
            for (InventoryItem item : currentItems) {
                inventoryData.append(item.getItemName()).append(":").append(item.getQuantity()).append("|");
            }
            // Save the inventory data to SharedPreferences
            SharedPreferences sharedPreferences = getSharedPreferences("inventory_prefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("inventory_data", inventoryData.toString());
            editor.apply();
        }
    }

    private void addItemToInventory(String itemName, int quantity) {
        // Get the current inventory from the ViewModel
        InventoryItem[] currentItems = inventoryViewModel.getInventoryLiveData().getValue();
        // Create a new list to hold the updated inventory
        List<InventoryItem> itemList = new ArrayList<>();
        // Add the existing items to the list
        if (currentItems != null) {
            itemList.addAll(Arrays.asList(currentItems));
        }
        // Add the new item to the list
        itemList.add(new InventoryItem(itemName, quantity));
        // Convert the list back to an array
        InventoryItem[] updatedItems = itemList.toArray(new InventoryItem[0]);
        // Update the ViewModel with the updated inventory
        inventoryViewModel.setInventory(updatedItems);
    }
}
