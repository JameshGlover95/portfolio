package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class main_menu extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_SEND_SMS = 1;
    private String userPhoneNumber; // Variable to hold user phone number

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        // Find buttons
        Button logoutButton = findViewById(R.id.button4);
        Button inventoryButton = findViewById(R.id.button7);
        Button getTextsButton = findViewById(R.id.button3);

        // Set click listeners
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement logout functionality here
                Toast.makeText(main_menu.this, "Logged out", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(main_menu.this, MainActivity.class);
                startActivity(intent);
                finish(); // Finish the current activity to prevent the user from coming back with the back button
            }
        });

        inventoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement inventory functionality here
                Toast.makeText(main_menu.this, "Go to Inventory", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(main_menu.this, Inventory.class);
                startActivity(intent);
                finish(); // Finish the current activity to prevent the user from coming back with the back button
            }
        });

        getTextsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement get texts functionality here
                Toast.makeText(main_menu.this, "Get Texts", Toast.LENGTH_SHORT).show();

                // Pass user phone number to Permissions activity and request permission
                Permissions permissions = new Permissions(main_menu.this, userPhoneNumber);
                permissions.sendSmsIfInventoryLow();
            }
        });
    }

    // Method to set user phone number
    public void setUserPhoneNumber(String phoneNumber) {
        this.userPhoneNumber = phoneNumber;
    }
}
