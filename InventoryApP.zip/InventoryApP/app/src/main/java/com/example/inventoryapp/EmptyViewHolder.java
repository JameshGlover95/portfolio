package com.example.inventoryapp;

// EmptyViewHolder.java
import android.view.View;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class EmptyViewHolder extends RecyclerView.ViewHolder {

    public EmptyViewHolder(@NonNull View itemView) {
        super(itemView);
        // Initialize empty state views if needed
    }
}
