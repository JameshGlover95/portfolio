package contactservice;

import static org.junit.Assert.*;
import org.junit.Test;
public class ContactServiceTest {

    @Test
    public void testValidContactCreation() {
        // Test valid contact creation
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("12345", contact.getContactID());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidContactID() {
        // Test invalid contact ID (exceeds 10 characters)
        new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidFirstName() {
        // Test invalid first name (exceeds 10 characters)
        new Contact("12345", "JohnJohnJohn", "Doe", "1234567890", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidLastName() {
        // Test invalid last name (exceeds 10 characters)
        new Contact("12345", "John", "DoeDoeDoe", "1234567890", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidPhone() {
        // Test invalid phone number (not exactly 10 digits)
        new Contact("12345", "John", "Doe", "123456789", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidAddress() {
        // Test invalid address (exceeds 30 characters)
        new Contact("12345", "John", "Doe", "1234567890", "123 Main St, Apartment 123, A Very Long Address");
    }
}