package contactservice;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contactMap;

    public ContactService() {
        contactMap = new HashMap<>();
    }

    public boolean addContact(Contact contact) {
        if (contactMap.containsKey(contact.getContactID())) {
            return false; // Contact with the same ID already exists
        }
        contactMap.put(contact.getContactID(), contact);
        return true;
    }

    public boolean deleteContact(String contactID) {
        if (contactMap.containsKey(contactID)) {
            contactMap.remove(contactID);
            return true;
        }
        return false; // Contact with the given ID not found
    }

    public boolean updateContact(String contactID, String firstName, String lastName, String phone, String address) {
        if (contactMap.containsKey(contactID)) {
            Contact contact = contactMap.get(contactID);

            // Update fields if they are not null and meet the requirements
            if (firstName != null && firstName.length() <= 10) {
                contact.setFirstName(firstName);
            }
            if (lastName != null && lastName.length() <= 10) {
                contact.setLastName(lastName);
            }
            if (phone != null && phone.length() == 10) {
                contact.setPhone(phone);
            }
            if (address != null && address.length() <= 30) {
                contact.setAddress(address);
            }

            return true;
        }
        return false; // Contact with the given ID not found
    }

    public Contact getContact(String contactID) {
        return contactMap.get(contactID);
    }
}